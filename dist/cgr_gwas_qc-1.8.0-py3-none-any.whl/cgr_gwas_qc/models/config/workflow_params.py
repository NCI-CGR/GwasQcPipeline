import time
from typing import Optional

from pydantic import BaseModel, Field

# setting start time to define unique lim file name
timestr = time.strftime("%Y%m%d%H%M%S")


class ConcordanceTools(BaseModel):
    graf: bool = Field(
        True,
        description="Are graf relatedness results needed? Even if True, the results won't be used in sample_concordance.",
    )
    king: bool = Field(
        True,
        description="Are king relateness results needed? Even if True, the results won't be used in sample_concordance.",
    )
    plink: bool = Field(
        True,
        description="Are plink ibd relateness results needed? It is the primary tool used in sample_qc report. If false, no replicate/relatedness check would be considered in sample_qc",
    )


class WorkflowParams(BaseModel):
    """This set of parameters controls which parts of the workflow are run and how they are executed

    .. code-block:: yaml

        workflow_params:
            subject_id_column: Group_By
            expected_sex_column: Expected_Sex
            sex_chr_included: true
            case_control_column: Case/Control_Status
            remove_contam: true
            remove_rep_discordant: true
            minimum_pop_subjects: 50
            control_hwp_threshold: 50
            lims_upload: true
            lims_output_dir: /DCEG/CGF/Laboratory/LIMS/drop-box-prod/gwas_primaryqc/
            case_control_gwas: false
            max_time_hr:
            max_mem_mb:
            time_start:
            convert_gtc2bcf: false
            additional_params_for_gtc2bcf: --use-gtc-sample-names
            convert_idat2gtc: false
            dragena_location:
            concordance_tools:
                graf: true
                king: true
                plink: true
    """

    subject_id_column: str = Field(
        "Group_By",
        description="The column in your sample sheet that contains the subject ID. "
        "We expect that there may be multiple samples (rows) that have the sample subject ID. "
        "If there are multiple columns that you want use for subject ID, you can create a special column named ``Group_By``. "
        "This would be a column that contains the column name to use as subject ID for that given samples (row).",
    )

    expected_sex_column: str = Field(
        "Expected_Sex",
        description="The name of the column in the sample sheet which identifies expected sex of samples. "
        "Allowed values in this columns are [``F`` | ``M`` | ``U``]",
    )

    sex_chr_included: bool = Field(
        True,
        description="True if the sex chromosome is included in the microarray and a sex concordance check can be performed.",
    )

    ancestry_snps_included: bool = Field(
        True,
        description="True if the ancestry informative SNPs are included in the microarray and a GRAF ancestry check can be performed.",
    )

    case_control_column: str = Field(
        "Case/Control_Status",
        description="The name of the colun in the sample sheet which identifies Case/Control status. "
        "Allowed values in this column are [``Control`` | ``Case`` | ``QC`` | ``Unknown``].",
    )

    remove_contam: bool = Field(
        True,
        description="True if you want to remove contaminated samples before running the subject level QC.",
    )

    remove_rep_discordant: bool = Field(
        True,
        description="True if you want to remove discordant replicates before running the subject level QC.",
    )

    minimum_pop_subjects: int = Field(
        50,
        gt=0,
        description="The minimum number of samples needed to use a population for population level QC (PCA, Autosomal Heterozygosity).",
    )

    control_hwp_threshold: int = Field(
        50,
        gt=0,
        description="The minimum number of control samples needed to use a population for population level QC (HWE).",
    )

    lims_upload: bool = Field(
        True,
        description="For ``CGEMS/CCAD`` use only, will place a copy of the LimsUpload file in the root directory.",
    )

    lims_output_dir: str = Field(
        "/DCEG/CGF/Laboratory/LIMS/drop-box-prod/gwas_primaryqc/",
        descrition="For ``CGEMS/CCAD`` use only, if lims_upload is set to true, the LimsUpload file will be copied to LIMS production directory or designated directory.",
    )

    case_control_gwas: bool = Field(
        False,
        description="A plink logistic regression gwas will be performed with case_control phenotype.",
    )

    max_time_hr: Optional[int] = Field(
        None,
        description="The maximum amount of time that can be requested, in hours.",
    )

    max_mem_mb: Optional[int] = Field(
        None,
        description="The maximum amount of memory that can be requests, in megabytes.",
    )

    time_start: str = Field(
        timestr,
        description="Date and time at which the workflow starts. This creates a unique id for the run.",
    )
    convert_gtc2bcf: bool = Field(
        False,
        description="If input is GTC, this switches between gtc2vcf (True) and gtc2ped (False - default) for conversion to BED.",
    )

    additional_params_for_gtc2bcf: str = Field(
        "--use-gtc-sample-names",
        description="Additional/optional parameters not hardcoded to be used or skipped in gtc2bcf for specific analysis.",
    )

    convert_idat2gtc: bool = Field(
        False,
        description="If idat_pattern is provided and `convert_idat2gtc` is `True`, idat2gtc will be triggered in entry_points.",
    )

    dragena_location: str = Field(
        None,
        description="Path to dragena binary. If dragena is not available as a module on HPC and IDAT entry_point is used, `dragena_location` will be used to convert idat2gtc.",
    )

    concordance_tools: Optional["ConcordanceTools"] = Field(
        ConcordanceTools(),
        description="The sample_concordance_summary only uses Plink."
        "If the outputs of graf and king relationship checks are needed, this option can be configured"
        "Please note even if graf and king relatedness checks are requested and executed, these would be for reference purpose only and not considered sample_concordance_summary.",
    )

    @staticmethod
    def schema_rst():
        """Tweak schema for rendering in Sphinx."""
        import copy
        import json

        content = copy.deepcopy(WorkflowParams.schema())
        content["title"] = "Workflow Parameters"

        return json.dumps(content, indent=2)
